﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{ 
    public partial class Registrtion : Form
    { 
        public Registrtion()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {   // Выбор колличества вопросов, в зависимости от темы
            if (ClassLibrary1.Data1.NameOfTheme == "Иерархия классов")
            {
                ClassLibrary1.Data1.NQW = 23;
                ClassLibrary1.Data1.NQWB = 24;


            }
            if (ClassLibrary1.Data1.NameOfTheme == "Все темы")
            {
                ClassLibrary1.Data1.NQW = 30;
                ClassLibrary1.Data1.NQWB = 111;


            }

            if (ClassLibrary1.Data1.NameOfTheme == "Интерфейс")
            {
                ClassLibrary1.Data1.NQW = 14;
                ClassLibrary1.Data1.NQWB = 15;


            }
            if (ClassLibrary1.Data1.NameOfTheme == "Перегрузка операций")
            {
                ClassLibrary1.Data1.NQW = 30;
                ClassLibrary1.Data1.NQWB = 42;


            }
            if (ClassLibrary1.Data1.NameOfTheme == "Классы")
            {
                ClassLibrary1.Data1.NQW = 29;
                ClassLibrary1.Data1.NQWB = 30;


            }
            
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "")
            {
                MessageBox.Show("Одно или несколько полей не заполнено.", "Ошибка!", MessageBoxButtons.OK);
            }
            else
            {
                this.Hide();
            }

        }
        /////////////////////////////////////////////////////////
       
        ///////Ограничения на ввод в поля////////////////
        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((!Char.IsLetterOrDigit(e.KeyChar)) && (e.KeyChar != 45) && (e.KeyChar != 32))
            {
                if (e.KeyChar == 8) { e.Handled = false; return; }
                e.Handled = true;
            }
        
         
        }
        
        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((!Char.IsLetter(e.KeyChar)))
            {
                if (e.KeyChar == 8) { e.Handled = false; return; }
                e.Handled = true;
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((!Char.IsLetter(e.KeyChar)))
            {
                if (e.KeyChar == 8) { e.Handled = false; return; }
                e.Handled = true;
            }
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((!Char.IsLetter(e.KeyChar)))
            {
                if (e.KeyChar == 8) { e.Handled = false; return; }
                e.Handled = true;
            }
        }
        private void Registrtion_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
            }
        }
        /////////////////////////////////////////////////////////
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            ClassLibrary1.Data1.NameOfTheme = Convert.ToString(this.comboBox1.SelectedItem);
           
        }

        private void Registrtion_Load(object sender, EventArgs e)
        {

        }



    }
}
