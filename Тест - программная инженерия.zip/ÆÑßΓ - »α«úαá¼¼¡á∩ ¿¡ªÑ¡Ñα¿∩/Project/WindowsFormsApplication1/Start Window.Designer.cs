﻿using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    partial class MainForm
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.CloseButton = new System.Windows.Forms.PictureBox();
            this.AboutButton = new System.Windows.Forms.PictureBox();
            this.Start_testButton = new System.Windows.Forms.PictureBox();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            ((System.ComponentModel.ISupportInitialize)(this.CloseButton)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AboutButton)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Start_testButton)).BeginInit();
            this.SuspendLayout();
            // 
            // CloseButton
            // 
            this.CloseButton.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.exit1;
            this.CloseButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CloseButton.Location = new System.Drawing.Point(267, 424);
            this.CloseButton.Name = "CloseButton";
            this.CloseButton.Size = new System.Drawing.Size(285, 97);
            this.CloseButton.TabIndex = 11;
            this.CloseButton.TabStop = false;
            this.CloseButton.Click += new System.EventHandler(this.CloseButton_Click);
            this.CloseButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.CloseButton_MouseDown);
            this.CloseButton.MouseEnter += new System.EventHandler(this.CloseButton_MouseEnter);
            this.CloseButton.MouseLeave += new System.EventHandler(this.CloseButton_MouseLeave);
            this.CloseButton.MouseUp += new System.Windows.Forms.MouseEventHandler(this.CloseButton_MouseUp);
            // 
            // AboutButton
            // 
            this.AboutButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("AboutButton.BackgroundImage")));
            this.AboutButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AboutButton.Location = new System.Drawing.Point(239, 292);
            this.AboutButton.Name = "AboutButton";
            this.AboutButton.Size = new System.Drawing.Size(350, 105);
            this.AboutButton.TabIndex = 12;
            this.AboutButton.TabStop = false;
            this.AboutButton.Click += new System.EventHandler(this.AboutButton_Click);
            this.AboutButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.AboutButton_MouseDown);
            this.AboutButton.MouseEnter += new System.EventHandler(this.AboutButton_MouseEnter);
            this.AboutButton.MouseLeave += new System.EventHandler(this.AboutButton_MouseLeave);
            this.AboutButton.MouseUp += new System.Windows.Forms.MouseEventHandler(this.AboutButton_MouseUp);
            // 
            // Start_testButton
            // 
            this.Start_testButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Start_testButton.BackgroundImage")));
            this.Start_testButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Start_testButton.Location = new System.Drawing.Point(206, 149);
            this.Start_testButton.Name = "Start_testButton";
            this.Start_testButton.Size = new System.Drawing.Size(425, 121);
            this.Start_testButton.TabIndex = 13;
            this.Start_testButton.TabStop = false;
            this.Start_testButton.Click += new System.EventHandler(this.Start_testButton_Click);
            this.Start_testButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Start_testButton_MouseDown);
            this.Start_testButton.MouseEnter += new System.EventHandler(this.Start_testButton_MouseEnter);
            this.Start_testButton.MouseLeave += new System.EventHandler(this.Start_testButton_MouseLeave);
            this.Start_testButton.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Start_testButton_MouseUp);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.bacground1;
            this.ClientSize = new System.Drawing.Size(850, 613);
            this.ControlBox = false;
            this.Controls.Add(this.Start_testButton);
            this.Controls.Add(this.AboutButton);
            this.Controls.Add(this.CloseButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Тест по Программной инженерии";
            this.TransparencyKey = System.Drawing.Color.Black;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseMove);
            ((System.ComponentModel.ISupportInitialize)(this.CloseButton)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AboutButton)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Start_testButton)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private PictureBox CloseButton;
        private PictureBox AboutButton;
        private PictureBox Start_testButton;
        private FolderBrowserDialog folderBrowserDialog1;

    }
}

