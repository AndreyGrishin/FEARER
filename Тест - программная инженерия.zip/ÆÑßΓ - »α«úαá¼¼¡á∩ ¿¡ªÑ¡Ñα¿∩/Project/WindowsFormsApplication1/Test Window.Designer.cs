﻿namespace WindowsFormsApplication1
{
    partial class TestForm
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TestForm));
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.Иерархия_Классов = new WindowsFormsApplication1.DataSetNewTableAdapters.Иерархия_КлассаTableAdapter();
            this.Интерфейс = new WindowsFormsApplication1.DataSetNewTableAdapters.ИнтерфейсTableAdapter();
            this.Классы = new WindowsFormsApplication1.DataSetNewTableAdapters.КлассыTableAdapter();
            this.Перегрузка_операций = new WindowsFormsApplication1.DataSetNewTableAdapters.Перегрузка_ОперацийTableAdapter();
            this.Все_темы = new WindowsFormsApplication1.DataSetNewTableAdapters.Вопросы_части_АTableAdapter();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.ReplyButton = new System.Windows.Forms.PictureBox();
            this.SkipButton = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.ReplyButton)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SkipButton)).BeginInit();
            this.SuspendLayout();
            // 
            // radioButton1
            // 
            this.radioButton1.BackColor = System.Drawing.Color.Transparent;
            this.radioButton1.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold);
            this.radioButton1.Location = new System.Drawing.Point(43, 266);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(938, 40);
            this.radioButton1.TabIndex = 2;
            this.radioButton1.TabStop = true;
            this.radioButton1.UseVisualStyleBackColor = false;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.BackColor = System.Drawing.Color.Transparent;
            this.radioButton2.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold);
            this.radioButton2.Location = new System.Drawing.Point(43, 321);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(938, 40);
            this.radioButton2.TabIndex = 3;
            this.radioButton2.TabStop = true;
            this.radioButton2.UseVisualStyleBackColor = false;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // radioButton3
            // 
            this.radioButton3.BackColor = System.Drawing.Color.Transparent;
            this.radioButton3.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold);
            this.radioButton3.ForeColor = System.Drawing.Color.Black;
            this.radioButton3.Location = new System.Drawing.Point(43, 371);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(938, 40);
            this.radioButton3.TabIndex = 4;
            this.radioButton3.TabStop = true;
            this.radioButton3.UseVisualStyleBackColor = false;
            this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // radioButton4
            // 
            this.radioButton4.BackColor = System.Drawing.Color.Transparent;
            this.radioButton4.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold);
            this.radioButton4.Location = new System.Drawing.Point(43, 421);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(938, 40);
            this.radioButton4.TabIndex = 5;
            this.radioButton4.TabStop = true;
            this.radioButton4.UseVisualStyleBackColor = false;
            this.radioButton4.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Иерархия_Классов
            // 
            this.Иерархия_Классов.ClearBeforeFill = true;
            // 
            // Интерфейс
            // 
            this.Интерфейс.ClearBeforeFill = true;
            // 
            // Классы
            // 
            this.Классы.ClearBeforeFill = true;
            // 
            // Перегрузка_операций
            // 
            this.Перегрузка_операций.ClearBeforeFill = true;
            // 
            // Все_темы
            // 
            this.Все_темы.ClearBeforeFill = true;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(127, 88);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(759, 138);
            this.label1.TabIndex = 13;
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 15.25F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(420, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 24);
            this.label2.TabIndex = 14;
            // 
            // ReplyButton
            // 
            this.ReplyButton.BackColor = System.Drawing.Color.Transparent;
            this.ReplyButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ReplyButton.BackgroundImage")));
            this.ReplyButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ReplyButton.Location = new System.Drawing.Point(78, 486);
            this.ReplyButton.Name = "ReplyButton";
            this.ReplyButton.Size = new System.Drawing.Size(240, 77);
            this.ReplyButton.TabIndex = 15;
            this.ReplyButton.TabStop = false;
            this.ReplyButton.Click += new System.EventHandler(this.pictureBox1_Click);
            this.ReplyButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseDown);
            this.ReplyButton.MouseEnter += new System.EventHandler(this.pictureBox1_MouseEnter);
            this.ReplyButton.MouseLeave += new System.EventHandler(this.ReplyButton_MouseLeave);
            this.ReplyButton.MouseUp += new System.Windows.Forms.MouseEventHandler(this.ReplyButton_MouseUp);
            // 
            // SkipButton
            // 
            this.SkipButton.BackColor = System.Drawing.Color.Transparent;
            this.SkipButton.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.skip_button0;
            this.SkipButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SkipButton.Location = new System.Drawing.Point(711, 482);
            this.SkipButton.Name = "SkipButton";
            this.SkipButton.Size = new System.Drawing.Size(244, 81);
            this.SkipButton.TabIndex = 16;
            this.SkipButton.TabStop = false;
            this.SkipButton.Click += new System.EventHandler(this.pictureBox1_Click_2);
            this.SkipButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.SkipButton_MouseDown);
            this.SkipButton.MouseEnter += new System.EventHandler(this.SkipButton_MouseEnter);
            this.SkipButton.MouseLeave += new System.EventHandler(this.SkipButton_MouseLeave);
            this.SkipButton.MouseUp += new System.Windows.Forms.MouseEventHandler(this.SkipButton_MouseUp);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Impact", 25.25F);
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(453, 513);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(104, 42);
            this.label3.TabIndex = 17;
            this.label3.Text = "10 : 00";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // TestForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1024, 568);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.SkipButton);
            this.Controls.Add(this.ReplyButton);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.radioButton4);
            this.Controls.Add(this.radioButton3);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "TestForm";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form2";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form2_FormClosing);
            this.Load += new System.EventHandler(this.TestForm_Load);
            this.Shown += new System.EventHandler(this.Form2_Shown);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form2_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Form2_MouseMove);
            ((System.ComponentModel.ISupportInitialize)(this.ReplyButton)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SkipButton)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton4;
        private DataSetNew dtatbaseDataSet = new DataSetNew();
        private WindowsFormsApplication1.DataSetNewTableAdapters.Иерархия_КлассаTableAdapter Иерархия_Классов;
      private WindowsFormsApplication1.DataSetNewTableAdapters.ИнтерфейсTableAdapter Интерфейс;
      private WindowsFormsApplication1.DataSetNewTableAdapters.КлассыTableAdapter Классы;
      private WindowsFormsApplication1.DataSetNewTableAdapters.Перегрузка_ОперацийTableAdapter Перегрузка_операций;
      private WindowsFormsApplication1.DataSetNewTableAdapters.Вопросы_части_АTableAdapter Все_темы;
      //  private WindowsFormsApplication1.DtatbaseDataSetTableAdapters.Вопросы_части_BTableAdapter вопросы_части_BTableAdapter;
      private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox ReplyButton;
        private System.Windows.Forms.PictureBox SkipButton;
        private System.Windows.Forms.Label label3;
    }
}