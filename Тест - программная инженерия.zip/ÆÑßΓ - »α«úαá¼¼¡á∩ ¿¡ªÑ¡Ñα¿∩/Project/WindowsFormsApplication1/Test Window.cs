﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Resources;
using WindowsFormsApplication1.Properties;
using System.Windows.Forms;
using ClassLibrary1;

namespace WindowsFormsApplication1
{
    public partial class TestForm : Form
    {
        Data1.Questions[] QuestionsA;
        int RightANSWA;
        int QWnumber;
        string TextANSW;
        string RTextANSW;
        int seconds;
        int minutes;
        bool tflag;
        bool eflag;
        Random r = new Random();
      
        ResultForm form4 = new ResultForm();
    //   public static int NQW = 23; //Количество вопросов
    //   public static int NQWB = 24; //Количество вопросов в БАЗЕ
        public Point mouse_offset;
        public TestForm()
        {
            InitializeComponent();
           
                   
        }

        private void Form2_Shown(object sender, EventArgs e)
        {
            Registrtion form3 = new Registrtion();

            
            Text = (Data1.Gflag) ? "Контрольное тестирование" : "Пробное тестирование";
            ControlBox = (Data1.Gflag) ? false : true;
            label3.Text = (Data1.Gflag) ? "10 : 00" : "00 : 00";
            radioButton1.Visible = true;
            radioButton2.Visible = true;
            radioButton3.Visible = true;
            radioButton4.Visible = true;
            radioButton1.Text = "";
            radioButton2.Text = "";
            radioButton3.Text = "";
            radioButton4.Text = "";
           this.label1.Text = "";

           Data1.NumberOfAsk = 1;
           
            if (Data1.Gflag)
            {
                form3.ShowDialog();
                Data1.Group = form3.textBox1.Text;
                Data1.Surname = form3.textBox2.Text;
                Data1.Name = form3.textBox3.Text;
                Data1.Fathers_name = form3.textBox4.Text;
            }
        
            RightANSWA = 0;
            QWnumber = 0;
            TextANSW = "";
            RTextANSW = "";
            if (Data1.Gflag)
            {
                minutes = 10;
                seconds = 0;
            }
            else 
            {
                minutes = 0; 
                seconds = 1;
            }
            tflag = true;
            eflag = false;
            QuestionsA = new Data1.Questions[Data1.NQW];
            Fill_Numbs();
            FillQW(QuestionsA[0].NinB);
            if (Data1.Gflag) { label3.Text = "10 : 00"; }
            else { label3.Text = "00 : 00"; } 
            timer1.Enabled = true;

        }

        private void HideMe()
        {
            timer1.Enabled = false;
            Data1.min = minutes;
            Data1.sec = seconds;
            Data1.RAA = RightANSWA;
            form4.ShowDialog();
            eflag = true;
            Close();
        }

        private void Fill_Numbs()
        {

            int N;
            for (int i = 0; i < Data1.NQW; i++)
            {
                bool fl;

                do
                {
                    fl = false;
                    N = r.Next(0, Data1.NQWB - 1);
                    for (int j = 0; j <= i - 1; j++)
                    {
                        if (N == QuestionsA[j].NinB)
                        { fl = true; break; }
                    }
                }
                while (fl);

                QuestionsA[i].NinB = N;
                QuestionsA[i].Answered = false;
            }
        }

        public void FillQW(int number)
        {
            this.label2.Text = "Вопрос : " + Data1.NumberOfAsk.ToString()+" из "+ Data1.NQW.ToString();
           // вопросы в зависимости от выбранной темы
            if (ClassLibrary1.Data1.NameOfTheme == "Иерархия классов")                                // тема иерархия классов
            {

                

                this.label1.Text = dtatbaseDataSet.Иерархия_Класса.Rows[number][1].ToString();
                radioButton1.Text = dtatbaseDataSet.Иерархия_Класса.Rows[number][2].ToString();
                radioButton2.Text = dtatbaseDataSet.Иерархия_Класса.Rows[number][3].ToString();
                radioButton3.Text = dtatbaseDataSet.Иерархия_Класса.Rows[number][4].ToString();
                radioButton4.Text = dtatbaseDataSet.Иерархия_Класса.Rows[number][5].ToString();
                if (radioButton1.Text == "") { radioButton1.Visible = false; }
                if (radioButton2.Text == "") { radioButton2.Visible = false; }
                if (radioButton3.Text == "") { radioButton3.Visible = false; }
                if (radioButton4.Text == "") { radioButton4.Visible = false; }
                if (radioButton1.Text != "") { radioButton1.Visible = true; }
                if (radioButton2.Text != "") { radioButton2.Visible = true; }
                if (radioButton3.Text != "") { radioButton3.Visible = true; }
                if (radioButton4.Text != "") { radioButton4.Visible = true; }
                RTextANSW = dtatbaseDataSet.Иерархия_Класса.Rows[number][6].ToString();
            }
            if (ClassLibrary1.Data1.NameOfTheme == "Интерфейс")                                      // тема интерфейс
            {



                this.label1.Text = dtatbaseDataSet.Интерфейс.Rows[number][1].ToString();
                radioButton1.Text = dtatbaseDataSet.Интерфейс.Rows[number][2].ToString();
                radioButton2.Text = dtatbaseDataSet.Интерфейс.Rows[number][3].ToString();
                radioButton3.Text = dtatbaseDataSet.Интерфейс.Rows[number][4].ToString();
                radioButton4.Text = dtatbaseDataSet.Интерфейс.Rows[number][5].ToString();
                if (radioButton1.Text == "") { radioButton1.Visible = false; }
                if (radioButton2.Text == "") { radioButton2.Visible = false; }
                if (radioButton3.Text == "") { radioButton3.Visible = false; }
                if (radioButton4.Text == "") { radioButton4.Visible = false; }
                if (radioButton1.Text != "") { radioButton1.Visible = true; }
                if (radioButton2.Text != "") { radioButton2.Visible = true; }
                if (radioButton3.Text != "") { radioButton3.Visible = true; }
                if (radioButton4.Text != "") { radioButton4.Visible = true; }
                RTextANSW = dtatbaseDataSet.Интерфейс.Rows[number][6].ToString();
            }
            if (ClassLibrary1.Data1.NameOfTheme == "Классы")                                        // тема классы
            {



                this.label1.Text = dtatbaseDataSet.Классы.Rows[number][1].ToString();
                radioButton1.Text = dtatbaseDataSet.Классы.Rows[number][2].ToString();
                radioButton2.Text = dtatbaseDataSet.Классы.Rows[number][3].ToString();
                radioButton3.Text = dtatbaseDataSet.Классы.Rows[number][4].ToString();
                radioButton4.Text = dtatbaseDataSet.Классы.Rows[number][5].ToString();
                if (radioButton1.Text == "") { radioButton1.Visible = false; }
                if (radioButton2.Text == "") { radioButton2.Visible = false; }
                if (radioButton3.Text == "") { radioButton3.Visible = false; }
                if (radioButton4.Text == "") { radioButton4.Visible = false; }
                if (radioButton1.Text != "") { radioButton1.Visible = true; }
                if (radioButton2.Text != "") { radioButton2.Visible = true; }
                if (radioButton3.Text != "") { radioButton3.Visible = true; }
                if (radioButton4.Text != "") { radioButton4.Visible = true; }
                RTextANSW = dtatbaseDataSet.Классы.Rows[number][6].ToString();
            }
            if (ClassLibrary1.Data1.NameOfTheme == "Перегрузка операций")                                        // тема перегрузка операций
            {



                this.label1.Text = dtatbaseDataSet.Перегрузка_Операций.Rows[number][1].ToString();
                radioButton1.Text = dtatbaseDataSet.Перегрузка_Операций.Rows[number][2].ToString();
                radioButton2.Text = dtatbaseDataSet.Перегрузка_Операций.Rows[number][3].ToString();
                radioButton3.Text = dtatbaseDataSet.Перегрузка_Операций.Rows[number][4].ToString();
                radioButton4.Text = dtatbaseDataSet.Перегрузка_Операций.Rows[number][5].ToString();
                if (radioButton1.Text == "") { radioButton1.Visible = false; }
                if (radioButton2.Text == "") { radioButton2.Visible = false; }
                if (radioButton3.Text == "") { radioButton3.Visible = false; }
                if (radioButton4.Text == "") { radioButton4.Visible = false; }
                if (radioButton1.Text != "") { radioButton1.Visible = true; }
                if (radioButton2.Text != "") { radioButton2.Visible = true; }
                if (radioButton3.Text != "") { radioButton3.Visible = true; }
                if (radioButton4.Text != "") { radioButton4.Visible = true; }
                RTextANSW = dtatbaseDataSet.Перегрузка_Операций.Rows[number][6].ToString();

            }
            if (ClassLibrary1.Data1.NameOfTheme == "Все темы")                                // тема иерархия классов
            {



                this.label1.Text = dtatbaseDataSet.Вопросы_части_А.Rows[number][1].ToString();
                radioButton1.Text = dtatbaseDataSet.Вопросы_части_А.Rows[number][2].ToString();
                radioButton2.Text = dtatbaseDataSet.Вопросы_части_А.Rows[number][3].ToString();
                radioButton3.Text = dtatbaseDataSet.Вопросы_части_А.Rows[number][4].ToString();
                radioButton4.Text = dtatbaseDataSet.Вопросы_части_А.Rows[number][5].ToString();
                if (radioButton1.Text == "") { radioButton1.Visible = false; }
                if (radioButton2.Text == "") { radioButton2.Visible = false; }
                if (radioButton3.Text == "") { radioButton3.Visible = false; }
                if (radioButton4.Text == "") { radioButton4.Visible = false; }
                if (radioButton1.Text != "") { radioButton1.Visible = true; }
                if (radioButton2.Text != "") { radioButton2.Visible = true; }
                if (radioButton3.Text != "") { radioButton3.Visible = true; }
                if (radioButton4.Text != "") { radioButton4.Visible = true; }
                RTextANSW = dtatbaseDataSet.Вопросы_части_А.Rows[number][6].ToString();
            }
         
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton rb = sender as RadioButton;
            TextANSW = rb.Text;
        }

        public void LoadQW(int pos, bool flag)
        {
            for (int i = pos; i <= ClassLibrary1.Data1.NQW - 1; i++)
                {
                    if (QuestionsA[i].NinB == -1)
                    {
                        int Next = r.Next(i * 4, (i + 1) * 4 - 1);
                        FillQW(Next);
                        return;
                    }
                }

            for (int i = pos; i <= ClassLibrary1.Data1.NQW - 1; i++)
                {
                    if (!QuestionsA[i].Answered)
                    {
                        FillQW(QuestionsA[i].NinB);
                        QWnumber = i;
                        return;
                    }
                }

            for (int i = 0; i <= ClassLibrary1.Data1.NQW - 1; i++)
                {
                    if (!QuestionsA[i].Answered)
                    {
                        FillQW(QuestionsA[i].NinB);
                        QWnumber = i;
                        return;
                    }
                }
                HideMe();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Data1.NumberOfAsk++;
            if (TextANSW == "") 
            { 
                MessageBox.Show("Необходимо ответить на вопрос.", "Ошибка!", MessageBoxButtons.OK);
                return;
            }
            if (TextANSW == RTextANSW) { RightANSWA++;}
            QuestionsA[QWnumber].Answered = true;
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            radioButton3.Checked = false;
            radioButton4.Checked = false;
            TextANSW = "";
            if (QWnumber >= 19) { QWnumber = 0; }
            QWnumber++;
            LoadQW(QWnumber,true);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            radioButton3.Checked = false;
            radioButton4.Checked = false;
            TextANSW = "";
            if (QWnumber >= 19) { QWnumber = 0; }
            QWnumber++;
            LoadQW(QWnumber, true);
        }

    
        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Data1.Gflag)
            {
                if ((e.CloseReason == CloseReason.UserClosing) && (!eflag))
                {
                    MessageBox.Show("Вы не можете выйти до окончания тестирования!", "Ошибка!", MessageBoxButtons.OK);
                    e.Cancel = true;
                }
            }
            else 
            {
                if ((e.CloseReason == CloseReason.UserClosing) && (!eflag))
                {
                    if (MessageBox.Show("Вы уверены, что хотите выйти?", "Выход", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        e.Cancel = false; timer1.Enabled = false; return;
                    }
                    else 
                    {
                        e.Cancel = true; return;
                    }                   
                }
            }
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (Data1.Gflag)
            {
                if (seconds == 0) { minutes--; seconds = 59; }
                if (tflag)
                {
                    label3.Text = string.Format("{0}{1} : {2}{3}", (int)minutes / 10, minutes % 10, (int)seconds / 10, seconds % 10);
                }
                seconds--;
                if (minutes == 0 && seconds == 0)
                {
                    timer1.Enabled = false;
                    Application.DoEvents();
                    System.Threading.Thread.Sleep(1000);
                    label3.Text = string.Format("{0}{1} : {2}{3}", (int)minutes / 10, minutes % 10, (int)seconds / 10, seconds % 10);
                    MessageBox.Show("Извините, но время, отведенное на выполнение контрольного тестирования, вышло.", "Время вышло", MessageBoxButtons.OK);
                    HideMe();
                }
            }
            else 
            {
                if (seconds == 59) { minutes++; seconds = 0; }
                if (tflag)
                {
                    label3.Text = string.Format("{0}{1} : {2}{3}", (int)minutes / 10, minutes % 10, (int)seconds / 10, seconds % 10);
                }
                seconds++; 
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void TestForm_Load(object sender, EventArgs e)
        {
           this.Иерархия_Классов.Fill(this.dtatbaseDataSet.Иерархия_Класса);   // загрузка данных в таблицу
           this.Интерфейс.Fill(this.dtatbaseDataSet.Интерфейс);
           this.Классы.Fill(this.dtatbaseDataSet.Классы);
           this.Перегрузка_операций.Fill(this.dtatbaseDataSet.Перегрузка_Операций);
           this.Все_темы.Fill(this.dtatbaseDataSet.Вопросы_части_А);
            DoubleBuffered = true;
            
        }
        private void Form2_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Point mousePos = Control.MousePosition;
                mousePos.Offset(mouse_offset.X, mouse_offset.Y);
                Location = mousePos;
            }

        }
        private void Form2_MouseDown(object sender, MouseEventArgs e)
        {
            mouse_offset = new Point(-e.X, -e.Y);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Data1.NumberOfAsk++;
            if (TextANSW == "")
            {
                MessageBox.Show("Необходимо ответить на вопрос.", "Ошибка!", MessageBoxButtons.OK);
                return;
            }
            if (TextANSW == RTextANSW) { RightANSWA++; }
            QuestionsA[QWnumber].Answered = true;
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            radioButton3.Checked = false;
            radioButton4.Checked = false;
            TextANSW = "";
            if (QWnumber >= 19) { QWnumber = 0; }
            QWnumber++;
            LoadQW(QWnumber, true);
        }
        private void label3_Click(object sender, EventArgs e)
        {
            if (minutes > 9) { label3.Text = string.Format("{0} : {1}", minutes, seconds); }
            else { label3.Text = string.Format("0{0} : {1}", minutes, seconds); }

            // tflag = !tflag;

        }
        private void pictureBox1_Click_2(object sender, EventArgs e)
        {
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            radioButton3.Checked = false;
            radioButton4.Checked = false;
            TextANSW = "";
            if (QWnumber >= 19) { QWnumber = 0; }
            QWnumber++;
            LoadQW(QWnumber, true);
        }
        ////////Эффекты кнопок//////////////////////////////
        ///////Ответить////////////////////////////////////
        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            ReplyButton.Image = (Bitmap)Resources.ResourceManager.GetObject("reply_button3");
        }

        private void pictureBox1_MouseEnter(object sender, EventArgs e)
        {
            ReplyButton.Image = (Bitmap)Resources.ResourceManager.GetObject("reply_button2");
        }

        private void ReplyButton_MouseLeave(object sender, EventArgs e)
        {
            ReplyButton.Image = (Bitmap)Resources.ResourceManager.GetObject("reply_button");
        }
        private void ReplyButton_MouseUp(object sender, MouseEventArgs e)
        {
            ReplyButton.Image = (Bitmap)Resources.ResourceManager.GetObject("reply_button");
        }
        ///////////////////////////////////////////////
        //////////Пропустить///////////////////////////
        private void SkipButton_MouseDown(object sender, MouseEventArgs e)
        {
            SkipButton.Image = (Bitmap)Resources.ResourceManager.GetObject("skip_button3");
        }

        private void SkipButton_MouseEnter(object sender, EventArgs e)
        {
            SkipButton.Image = (Bitmap)Resources.ResourceManager.GetObject("skip_button2");
        }

        private void SkipButton_MouseUp(object sender, MouseEventArgs e)
        {
            SkipButton.Image = (Bitmap)Resources.ResourceManager.GetObject("skip_button0");
        }

        private void SkipButton_MouseLeave(object sender, EventArgs e)
        {
            SkipButton.Image = (Bitmap)Resources.ResourceManager.GetObject("skip_button0");
        }

       

        ///////////////////////////////////////////////////////////////////////

     }
}
