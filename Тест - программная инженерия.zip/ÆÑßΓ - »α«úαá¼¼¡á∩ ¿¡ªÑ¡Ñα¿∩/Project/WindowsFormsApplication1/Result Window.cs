﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using ClassLibrary1;

namespace WindowsFormsApplication1
{
    public partial class ResultForm : Form
    {
        bool eflag;

        public ResultForm()
        {
            InitializeComponent();
        }

        public void Form4_Shown(object sender, EventArgs e)
        {
            FillRTB(Data1.Gflag);
        }
        ///////////Вывод результата/////////////////////
        public void FillRTB(bool flag) 
        {
            if (flag)
            {
                richTextBox1.Text = "Группа:  " 
                + Data1.Group+ "\nФамилия:  " + Data1.Surname + "\nИмя:  " + Data1.Name 
                +"\nОтчество:  " +Data1.Fathers_name + "\nТема : "+Data1.NameOfTheme+ "\n\nКоличество баллов:   " 
                + Data1.RAA.ToString()+" б." + " Из возможных "+ Data1.NQW+ " б.\nВ процентном соотношении  "+(Data1.RAA)*100/Data1.NQW
                + "%\nОсталось времени:  " +Data1.min +" : " + Data1.sec
                + "\nДата и время:  " + DateTime.Now;
            }
            else
            {
                richTextBox1.Text = "Уважаемый пользователь, Вы набрали:\n:   " 
                + Data1.RAA.ToString() + " б.:  Из "+" "+ Data1.NQW 
                + " б.\nВ процентном соотношении  "+(Data1.RAA + Data1.RAB)*100/Data1.NQW
                +"%\nПотрачено времени:  " + string.Format("{0} : {1}", Data1.min, Data1.sec);
            }
        }
        //////////////////////////////////////////////////////
        /////////Создание документа для вывода///////////////
        public void CraeteFile()
        {
            StreamWriter SW = new StreamWriter("Users\\" + Data1.Surname + " " + Data1.Name + ".doc", false, Encoding.Default);
            SW.WriteLine(richTextBox1.Text);
            SW.Close();
        }
        ///////////////////////////////////////////////////
        ////////Закрытие окна/////////////////////////////
        private void button1_Click(object sender, EventArgs e)
        {
            if (Data1.Gflag) { CraeteFile(); }
            eflag = true;
            Close();
        }
        ////////Завершенеи программы/////////////////////
        private void Form4_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing && !eflag)
            {
                e.Cancel = true;
            }
        }
        ////////////////////////////////////////////////
        private void ResultsForm_Load(object sender, EventArgs e)
        {

        }
    }
}
