﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Resources;
using WindowsFormsApplication1.Properties;
using ClassLibrary1;

namespace WindowsFormsApplication1
{
    public partial class MainForm : Form
    { 
        TestForm form2 = new TestForm();
        Help form6 = new Help();
        public Point mouse_offset;
        public MainForm()
        {
            InitializeComponent();
            //System.Threading.Thread.Sleep(4000);
            Application.DoEvents();
           
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            DoubleBuffered = true;
        }

     /////////// Движение формы ////////////////////
        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Point mousePos = Control.MousePosition;
                mousePos.Offset(mouse_offset.X, mouse_offset.Y);
                Location = mousePos;
            }

        }
        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            mouse_offset = new Point(-e.X, -e.Y);
        }
        ////////////////////////////////////


        ////////// Эффекты кнопок/////////////
        //////////Начать тест/////////////////
        private void Start_testButton_Click(object sender, EventArgs e)
        {
            Data1.Gflag = true;
            form2.ShowDialog();
        }
        private void Start_testButton_MouseDown(object sender, MouseEventArgs e)
        {
            Start_testButton.Image = (Bitmap)Resources.ResourceManager.GetObject("start_test3");
        }

        private void Start_testButton_MouseEnter(object sender, EventArgs e)
        {
            Start_testButton.Image = (Bitmap)Resources.ResourceManager.GetObject("start_test2");
        }

        private void Start_testButton_MouseUp(object sender, MouseEventArgs e)
        {
            Start_testButton.Image = (Bitmap)Resources.ResourceManager.GetObject("start_test");
        }

        private void Start_testButton_MouseLeave(object sender, EventArgs e)
        {
            Start_testButton.Image = (Bitmap)Resources.ResourceManager.GetObject("start_test");
        }
        /////////////////////////////////////////////////////
        /////////////Справка////////////////////////////////
        private void AboutButton_Click(object sender, EventArgs e)
        {
            form6.ShowDialog();
        }
        private void AboutButton_MouseDown(object sender, MouseEventArgs e)
        {
            AboutButton.Image = (Bitmap)Resources.ResourceManager.GetObject("about3");
        }

        private void AboutButton_MouseEnter(object sender, EventArgs e)
        {
            AboutButton.Image = (Bitmap)Resources.ResourceManager.GetObject("about2");
        }
        private void AboutButton_MouseLeave(object sender, EventArgs e)
        {
            AboutButton.Image = (Bitmap)Resources.ResourceManager.GetObject("about");
        }

        private void AboutButton_MouseUp(object sender, MouseEventArgs e)
        {
            AboutButton.Image = (Bitmap)Resources.ResourceManager.GetObject("about");
        }
        ////////////////////////////////////////////////////
        ///////////Выйти///////////////////////////////////
        private void CloseButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void CloseButton_MouseDown(object sender, MouseEventArgs e)
        {
            CloseButton.Image = (Bitmap)Resources.ResourceManager.GetObject("exit3");
        }

        private void CloseButton_MouseEnter(object sender, EventArgs e)
        {
            CloseButton.Image = (Bitmap)Resources.ResourceManager.GetObject("exit2");
        }

        private void CloseButton_MouseLeave(object sender, EventArgs e)
        {
            CloseButton.Image = (Bitmap)Resources.ResourceManager.GetObject("exit");
        }

        private void CloseButton_MouseUp(object sender, MouseEventArgs e)
        {
            CloseButton.Image = (Bitmap)Resources.ResourceManager.GetObject("exit");
        }




        
    }
}
