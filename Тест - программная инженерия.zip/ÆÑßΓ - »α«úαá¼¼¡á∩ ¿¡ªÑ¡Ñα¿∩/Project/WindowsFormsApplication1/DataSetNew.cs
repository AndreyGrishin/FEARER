﻿namespace WindowsFormsApplication1 {
    
    
    public partial class DataSetNew {
        partial class Тема_2DataTable
        {
        }
    
        partial class Тема_1DataTable
        {
        }
    }
}
