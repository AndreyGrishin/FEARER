﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassLibrary1
{
    public class Data1
    {
        public static bool Gflag;
        public static int RAA;
        public static int RAB;
        public static string Name;
        public static string Surname;
        public static string Fathers_name;
        public static string Group;
        public static int min;
        public static int sec;
       
        public static string [] text = new string[5];
        public static string NameOfTheme;
        public static int NQW;
        public static int NQWB;
        public static int NumberOfAsk;
     

      

      

        public struct Questions
        {
            public int NinB;
            public bool Answered;
        }

    }
}
