﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using ClassLibrary1;

namespace WindowsFormsApplication1
{
    public partial class ResultsForm : Form
    {
        bool eflag;

        public ResultsForm()
        {
            InitializeComponent();
        }

        public void Form4_Shown(object sender, EventArgs e)
        {
            FillRTB(Data1.Gflag);
        }

        public void FillRTB(bool flag) 
        {
            if (flag)
            {
                richTextBox1.Text = "Группа:  " 
                + Data1.Group+ "\nФамилия:  " + Data1.Surname + "\nИмя:  " + Data1.Name 
                +"\nОтчество:  " + Data1.Fathers_name + "\n\nКоличество баллов:   " 
                + Data1.RAA.ToString() + " б.\nВ процентном соотношении  "+(Data1.RAA)*100/25 
                + "%\nОсталось времени:  " +Data1.min +" : " + Data1.sec
                + "\nДата и время:  " + DateTime.Now;
            }
            else
            {
                richTextBox1.Text = "Уважаемый пользователь, Вы набрали:\nПо части А:   " 
                + Data1.RAA.ToString() + " б.\nПо части В:   " + Data1.RAB.ToString() 
                + " б.\nВ процентном соотношении  "+(Data1.RAA + Data1.RAB)*100/28 
                +"%\nПотрачено времени:  " + string.Format("{0} : {1}", Data1.min, Data1.sec);
            }
        }

        public void CraeteFile()
        {
            StreamWriter SW = new StreamWriter("Users\\" + Data1.Surname + " " + Data1.Name + ".doc", false, Encoding.Default);
            SW.WriteLine(richTextBox1.Text);
            SW.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Data1.Gflag) { CraeteFile(); }
            eflag = true;
            Close();
        }

        private void Form4_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing && !eflag)
            {
                e.Cancel = true;
            }
        }
    }
}
