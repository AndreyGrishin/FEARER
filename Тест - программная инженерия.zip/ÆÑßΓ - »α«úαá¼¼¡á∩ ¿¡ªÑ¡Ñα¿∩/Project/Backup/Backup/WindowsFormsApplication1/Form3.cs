﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class RegForm : Form
    {
        public RegForm()
        {
            InitializeComponent();
        }

        private void Form3_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing )
            {
                e.Cancel = true; 
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "")
            {
                MessageBox.Show("Одно или несколько полей не заполнено.", "Ошибка!", MessageBoxButtons.OK);
            }
            else 
            {
                this.Hide();
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((!Char.IsLetterOrDigit(e.KeyChar)) && (e.KeyChar != 45) && (e.KeyChar != 32))
            {
                if (e.KeyChar == 8) { e.Handled = false; return; }
                e.Handled = true;
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((!Char.IsLetter(e.KeyChar)))
            {
                if (e.KeyChar == 8) { e.Handled = false; return; }
                e.Handled = true;
            }
        }
    }
}
