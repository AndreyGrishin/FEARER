﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using ClassLibrary1;

namespace WindowsFormsApplication1
{
    public partial class MainForm : Form
    {
        TestForm form2 = new TestForm();
        LogForm form5 = new LogForm();
        HelpForm form6 = new HelpForm();

        public MainForm()
        {
            //form5.Show();
            InitializeComponent();
            //System.Threading.Thread.Sleep(4000);
            Application.DoEvents();
            Data1.Init_path();
            Data1.Init_text();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Data1.Gflag = true;
            form2.ShowDialog();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            form5.Hide();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            form6.ShowDialog();
        }
    }
}
