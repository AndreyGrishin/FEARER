﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ClassLibrary1;

namespace WindowsFormsApplication1
{
    public partial class TestForm : Form
    {
        Data1.Questions[] QuestionsA = new Data1.Questions[NQW];
        int RightANSWA;
        int QWnumber;
        string TextANSW;
        string RTextANSW;
        int seconds;
        int minutes;
        bool tflag;
        bool eflag;
        Random r = new Random();
        RegForm form3 = new RegForm();
        ResultsForm form4 = new ResultsForm();
        static int NQW = 15; //Количество вопросов!!!
        static int NQWB = 25; //Количество вопросов в БАЗЕ!!!

        public TestForm()
        {
            InitializeComponent();
            this.вопросы_части_АTableAdapter.Fill(this.dtatbaseDataSet.Вопросы_части_А);
        }

        private void Form2_Shown(object sender, EventArgs e)
        {
            Text = (Data1.Gflag) ? "Контрольное тестирование" : "Пробное тестирование";
            ControlBox = (Data1.Gflag) ? false : true;
            button2.Text = (Data1.Gflag) ? "30 : 00" : "00 : 00";
            radioButton1.Visible = true;
            radioButton2.Visible = true;
            radioButton3.Visible = true;
            radioButton4.Visible = true;
            radioButton1.Text = "";
            radioButton2.Text = "";
            radioButton3.Text = "";
            radioButton4.Text = "";
            pictureBox1.ImageLocation = "";

            Fill_Numbs();

            if (Data1.Gflag)
            {
                form3.ShowDialog();
                Data1.Group = form3.textBox1.Text;
                Data1.Surname = form3.textBox2.Text;
                Data1.Name = form3.textBox3.Text;
                Data1.Fathers_name = form3.textBox4.Text;
            }        

            RightANSWA = 0;
            QWnumber = 0;
            TextANSW = "";
            RTextANSW = "";
            if (Data1.Gflag)
            {
                minutes = 30;
                seconds = 0;
            }
            else 
            {
                minutes = 0; 
                seconds = 1;
            }
            tflag = true;
            eflag = false;

            FillQW(QuestionsA[0].NinB);
            if (Data1.Gflag) { button2.Text = "30 : 00"; }
            else { button2.Text = "00 : 00"; } 
            timer1.Enabled = true;
        }

        private void HideMe()
        {
            timer1.Enabled = false;
            Data1.min = minutes;
            Data1.sec = seconds;
            Data1.RAA = RightANSWA;
            form4.ShowDialog();
            eflag = true;
            Close();
        }

        private void Fill_Numbs()
        {
            int N;
            for (int i = 0; i < NQW; i++)
            {
                bool fl;

                do
                {
                    fl = false;
                    N = r.Next(0, NQWB - 1);
                    for (int j = 0; j <= i - 1; j++) 
                    {
                        if (N == QuestionsA[j].NinB)
                        { fl = true; break; }
                    }
                }
                while(fl);
                
                QuestionsA[i].NinB = N;
                QuestionsA[i].Answered = false;
            }
        }

        public void FillQW(int number)
        {
            pictureBox1.ImageLocation = dtatbaseDataSet.Вопросы_части_А.Rows[number][0].ToString();
            radioButton1.Text = dtatbaseDataSet.Вопросы_части_А.Rows[number][1].ToString();
            radioButton2.Text = dtatbaseDataSet.Вопросы_части_А.Rows[number][2].ToString();
            radioButton3.Text = dtatbaseDataSet.Вопросы_части_А.Rows[number][3].ToString();
            radioButton4.Text = dtatbaseDataSet.Вопросы_части_А.Rows[number][4].ToString();
            if (radioButton1.Text == "") { radioButton1.Visible = false; }
            if (radioButton2.Text == "") { radioButton2.Visible = false; }
            if (radioButton3.Text == "") { radioButton3.Visible = false; }
            if (radioButton4.Text == "") { radioButton4.Visible = false; }
            if (radioButton1.Text != "") { radioButton1.Visible = true; }
            if (radioButton2.Text != "") { radioButton2.Visible = true; }
            if (radioButton3.Text != "") { radioButton3.Visible = true; }
            if (radioButton4.Text != "") { radioButton4.Visible = true; }
            RTextANSW = dtatbaseDataSet.Вопросы_части_А.Rows[number][5].ToString();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton rb = sender as RadioButton;
            TextANSW = rb.Text;
        }

        public void LoadQW(int pos, bool flag)
        {
                for (int i = pos; i <= NQW - 1; i++)
                {
                    if (QuestionsA[i].NinB == -1)
                    {
                        int Next = r.Next(i * 4, (i + 1) * 4 - 1);
                        FillQW(Next);
                        return;
                    }
                }

                for (int i = pos; i <= NQW - 1; i++)
                {
                    if (!QuestionsA[i].Answered)
                    {
                        FillQW(QuestionsA[i].NinB);
                        QWnumber = i;
                        return;
                    }
                }

                for (int i = 0; i <= NQW - 1; i++)
                {
                    if (!QuestionsA[i].Answered)
                    {
                        FillQW(QuestionsA[i].NinB);
                        QWnumber = i;
                        return;
                    }
                }
                HideMe();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (TextANSW == "") 
            { 
                MessageBox.Show("Необходимо ответить на вопрос.", "Ошибка!", MessageBoxButtons.OK);
                return;
            }
            if (TextANSW == RTextANSW) { RightANSWA++;}
            QuestionsA[QWnumber].Answered = true;
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            radioButton3.Checked = false;
            radioButton4.Checked = false;
            TextANSW = "";
            if (QWnumber >= 19) { QWnumber = 0; }
            QWnumber++;
            LoadQW(QWnumber,true);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            radioButton3.Checked = false;
            radioButton4.Checked = false;
            TextANSW = "";
            if (QWnumber >= 19) { QWnumber = 0; }
            QWnumber++;
            LoadQW(QWnumber, true);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (tflag) { button2.Text = "Время"; } 
            else 
            {
                if (minutes > 9) { button2.Text = string.Format("{0} : {1}", minutes, seconds); }
                else { button2.Text = string.Format("0{0} : {1}", minutes, seconds); }
            }
            tflag  = !tflag;
        }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Data1.Gflag)
            {
                if ((e.CloseReason == CloseReason.UserClosing) && (!eflag))
                {
                    MessageBox.Show("Вы не можете выйти до окончания тестирования!", "Ошибка!", MessageBoxButtons.OK);
                    e.Cancel = true;
                }
            }
            else 
            {
                if ((e.CloseReason == CloseReason.UserClosing) && (!eflag))
                {
                    if (MessageBox.Show("Вы уверены, что хотите выйти?", "Выход", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        e.Cancel = false; timer1.Enabled = false; return;
                    }
                    else 
                    {
                        e.Cancel = true; return;
                    }                   
                }
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (Data1.Gflag)
            {
                if (seconds == 0) { minutes--; seconds = 59; }
                if (tflag)
                {
                    button2.Text = string.Format("{0}{1} : {2}{3}", (int)minutes / 10, minutes % 10, (int)seconds / 10, seconds % 10);
                }
                seconds--;
                if (minutes == 0 && seconds == 0)
                {
                    timer1.Enabled = false;
                    Application.DoEvents();
                    System.Threading.Thread.Sleep(1000);
                    button2.Text = string.Format("{0}{1} : {2}{3}", (int)minutes / 10, minutes % 10, (int)seconds / 10, seconds % 10);
                    MessageBox.Show("Извините, но время, отведенное на выполнение контрольного тестирования, вышло.", "Время вышло", MessageBoxButtons.OK);
                    HideMe();
                }
            }
            else 
            {
                if (seconds == 59) { minutes++; seconds = 0; }
                if (tflag)
                {
                    button2.Text = string.Format("{0}{1} : {2}{3}", (int)minutes / 10, minutes % 10, (int)seconds / 10, seconds % 10);
                }
                seconds++; 
            }
        }
     }
}
