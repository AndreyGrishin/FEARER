﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassLibrary1
{
    public class Data1
    {
        public static bool Gflag;
        public static int RAA;
        public static int RAB;
        public static string Name;
        public static string Surname;
        public static string Fathers_name;
        public static string Group;
        public static int min;
        public static int sec;
        private static string[] path = new string[11];
        public static string [] text = new string[5];

        public static void Init_path() 
        {
            path[0] = "Data\\Themes\\Алгоритмизация и программирование.rtf";
            path[1] = "Data\\Themes\\Базы данных.rtf";
            path[2] = "Data\\Themes\\Информационные модели.rtf";
            path[3] = "Data\\Themes\\Кодирование информации.rtf";
            path[4] = "Data\\Themes\\Кодирование информации.rtf";
            path[5] = "Data\\Themes\\Основы логики.rtf";
            path[6] = "Data\\Themes\\Сетевые технологии.rtf";
            path[7] = "Data\\Themes\\Системы счисления.rtf";
            path[8] = "Data\\Themes\\Файловая система компьютера.rtf";
            path[9] = "Data\\Themes\\Электронные таблицы .rtf";
        }

        public static void Init_text()
        {
            text[0] = "Эта опция позволит Вам пройти пробный тест и получить информацию о результате тестирования после него."
            +" Данная информацие ни где не сохраняется и служит лишь для примерного определения Вашего уровня знаний. Время " 
            + "выполнения не ограничевается, из теста можно выйти в любой момент.";

            text[1] = "\"Контрольное тестирование\" предназначено для определения Вашего уровня знаний по информатике в" 
            + " соответствии с нормами единого государственного экзамена на 2010г. Информация о результатах будет " 
            + "сохранена на жестком диске этого компьютера. Перед тестом Вам будет предложено заполнить регистрационную форму, " 
            + "пожалуйста будьте внимательны при её заполнении. Время на прохождение теста ограничено и составляет 90 минут. " 
            + "Вы не сможете выйти из программы до окончания тестирования.";

            text[2] = "Вызов окна справки и информации о данной программе.";
            text[3] = "Завершение работы программы.";
            text[4] = "Эта кнопка позволит свернуть программу и продолжить работу с Windows.";
        }

        public static string GetPath(int number)
        {
            return path[number];
        }

        public struct Questions
        {
            public int NinB;
            public bool Answered;
        }

    }
}
