﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HRDepartament
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        EmployeeDBEntities1 DBModel;
        public MainWindow()
        {
            InitializeComponent();
            DBModel = new EmployeeDBEntities1();
        }

        private void dataGrid_Loaded(object sender, RoutedEventArgs e)
        {
            /// Заполнение таблиц информацией из БД ///
            DBModel.Employee.Load();
            var query = from c in DBModel.Employee
                        select new { c.IdEmployee, c.First_Name, c.Sur_Name, c.Third_Name, c.StatusEmployee.Status_Name, c.Adress, c.Phone, c.IdManager, c.Subdivision.NameDivition };
              
            var query2 = from c in DBModel.Employee
                         where c.Subdivision.NameDivition == "Development department"
                         select new { c.IdEmployee, c.First_Name, c.Sur_Name, c.Third_Name, c.Adress, c.Phone, c.StatusEmployee.Status_Name };
            
            var query3 = from c in DBModel.Employee
                         where c.Subdivision.NameDivition == "Marketing department"
                         select new { c.IdEmployee, c.First_Name, c.Sur_Name, c.Third_Name, c.Adress, c.Phone, c.StatusEmployee.Status_Name };

            var query4 = from c in DBModel.Employee
                         where c.Subdivision.NameDivition == "Testing department"
                         select new { c.IdEmployee, c.First_Name, c.Sur_Name, c.Third_Name, c.Adress, c.Phone, c.StatusEmployee.Status_Name };

            var query5 = from c in DBModel.Employee
                         where c.Subdivision.NameDivition == "Security Service"
                         select new { c.IdEmployee, c.First_Name, c.Sur_Name, c.Third_Name, c.Adress, c.Phone, c.StatusEmployee.Status_Name };

            var query6 = from c in DBModel.Employee
                         where c.Subdivision.NameDivition == "Support service"
                         select new { c.IdEmployee, c.First_Name, c.Sur_Name, c.Third_Name, c.Adress, c.Phone, c.StatusEmployee.Status_Name };

            var query7 = from c in DBModel.StatusEmployee
                         select new { c.IdStatus, c.Status_Name };

            var query8 = from c in DBModel.Subdivision
                         select new { c.IdDivition, c.NameDivition };

            dataGrid.ItemsSource = DBModel.Employee.Local.ToBindingList();
            dataGrid2.ItemsSource = query7.ToList();
            dataGrid3.ItemsSource = query8.ToList();
            dataGrid4.ItemsSource = query3.ToList();
            dataGrid5.ItemsSource = query2.ToList();
            dataGrid6.ItemsSource = query4.ToList();
            dataGrid7.ItemsSource = query5.ToList();
            dataGrid8.ItemsSource = query6.ToList();
            //////////////////////////////////////////////////////
        }

        ///// Метод обновления элементов DataGrid ///
        public void RefreshDataGrid()
        {
            dataGrid.Items.Refresh();
            dataGrid4.Items.Refresh();
            dataGrid5.Items.Refresh();
            dataGrid6.Items.Refresh();
            dataGrid7.Items.Refresh();
            dataGrid8.Items.Refresh();
        }
        //////////////////////////////////////////
        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            DBModel.SaveChanges();
            RefreshDataGrid();
        }

        private void DelButton_Click_(object sender, RoutedEventArgs e)
        {
            Employee emp = dataGrid.SelectedItem as Employee;

            DBModel.Employee.Remove(emp);
            DBModel.SaveChanges();
            RefreshDataGrid();
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            AddNewEmployee addNew = new AddNewEmployee();
            addNew.Owner = this;
            addNew.ShowDialog();
            RefreshDataGrid();
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}
