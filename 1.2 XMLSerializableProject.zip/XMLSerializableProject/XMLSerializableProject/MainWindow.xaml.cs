﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.IO;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Serialization;
using Microsoft.Win32;

namespace XMLSerializableProject
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            
        }

        Settings instance1 = new Settings();
        Settings instance2;
        string filename;
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveFile = new SaveFileDialog();
            saveFile.Filter = "XML Files (*.xml)|*.xml";

            if (saveFile.ShowDialog() == true)
            {
                filename = saveFile.FileName;
                XmlSerializer serializer = new XmlSerializer(typeof(Settings));
                instance1.IPAdress = textBox_Copy.Text;
                instance1.Mask = textBox_Copy1.Text;
                instance1.DHCP = (bool)checkBox1.IsChecked;
                instance1.WIFIAccess = (bool)checkBox.IsChecked;
                instance1.SSID = textBox_Copy2.Text;

                using (var stream = new FileStream(filename, FileMode.Create, FileAccess.Write, FileShare.Read))
                {
                    serializer.Serialize(stream, instance1);
                }
            }
        }

        private void OpenButton_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFile = new OpenFileDialog();
            openFile.Filter = "XML Files (*.xml)|*.xml";

            if (openFile.ShowDialog() == true)
            {
                filename = openFile.FileName;
                XmlSerializer serializer = new XmlSerializer(typeof(Settings));
                try
                {
                    using (var stream = new FileStream(filename, FileMode.Open, FileAccess.Read, FileShare.Read))
                    {
                        instance2 = serializer.Deserialize(stream) as Settings;
                    }

                    textBox_Copy.Text = instance2.IPAdress;
                    textBox_Copy1.Text = instance2.Mask;
                    checkBox1.IsChecked = instance2.DHCP;
                    checkBox.IsChecked = instance2.WIFIAccess;
                    textBox_Copy2.Text = instance2.SSID;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
           
        }
    }
}
