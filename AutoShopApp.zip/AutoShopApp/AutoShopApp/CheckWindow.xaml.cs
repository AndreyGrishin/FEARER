﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AutoShopApp
{
    /// <summary>
    /// Логика взаимодействия для CheckWindow.xaml
    /// </summary>
    public partial class CheckWindow : Window
    {
        AutoShopDBEntities AutoShopModel;
        public CheckWindow()
        {
            InitializeComponent();
            AutoShopModel = new AutoShopDBEntities();
        }

        DateTime thisDate = DateTime.Now;
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            

        }

        private void label7_Loaded(object sender, RoutedEventArgs e)
        {
            WorkWindow ww = new WorkWindow();
            string name_customer = Data.Value;
            decimal orddet_cost = 0;
            int quantity = 0;
            string name;

            CheckDB checkDB = new CheckDB
            {
                Date = thisDate,
                NameCustomer = name_customer,
                TotalCost = orddet_cost
            };
            foreach (var item in AutoShopModel.OrderDetails)
            {
                name = item.NameProduct;
                quantity = item.Quantity;
                orddet_cost += item.Cost;

                AutoShopModel.CheckDB.Add(checkDB);

                CheckInfo checkinf = new CheckInfo
                {
                    IdCheck = checkDB.IdCheck,
                    NameModel = item.ModelName,
                    NameProduct = item.NameProduct,
                    VendorCode = item.VendorCode,
                    Quantity = item.Quantity,
                    Cost = item.Cost,
                };

                AutoShopModel.CheckInfo.Add(checkinf);
            }

            AutoShopModel.SaveChanges();

            label1.Content = checkDB.IdCheck;
            label3.Content = checkDB.Date;
            label5.Content = name_customer;
            label7.Content = orddet_cost + " руб.";
            dataGrid.ItemsSource = AutoShopModel.OrderDetails.ToList();

            

           }

       private void button_Click(object sender, RoutedEventArgs e)
       {
                PrintDialog printDialog = new PrintDialog();
               if (printDialog.ShowDialog() == true)
               {
                   printDialog.PrintVisual(GridPrited, "Печать чека");
               }

               this.Close();
        }
    }
}
