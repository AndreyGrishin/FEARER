﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AutoShopApp
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
       
        
        UsersEntities UsersModel = new UsersEntities();

        private void button_Click_1(object sender, RoutedEventArgs e)
        {
            string login = userNameTextBox.Text;
            foreach (var us in UsersModel.UsersTable)
            {
                if (us.Login == login.ToString() && us.Password == passwordTextBox.Password)
                {             
                    new WorkWindow().Show();
                    var query = from users in UsersModel.UsersTable
                                where users.Login == login
                                select new { users.Id};
                 this.Close();
                    break;
                }
                if (userNameTextBox.Text == string.Empty)
                {
                    MessageBox.Show("Введите логин");
                    break;
                }
                if (passwordTextBox.Password == string.Empty)
                {
                    MessageBox.Show("Введите пароль");
                    break;
                }
                else
                {
                    MessageBox.Show("Неверно введён логин или пароль");
                    break;
                }
            }
        }

        private void passwordTextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            passwordTextBox.Clear();
        }

        private void userNameTextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            userNameTextBox.Clear();
        }


        private void button_Click_2(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

    }
}
