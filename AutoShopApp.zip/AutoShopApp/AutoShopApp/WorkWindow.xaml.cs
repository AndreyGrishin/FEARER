﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Data.Entity;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.IO;

namespace AutoShopApp
{
    /// <summary>
    /// Логика взаимодействия для WorkWindow.xaml
    /// </summary>
    public partial class WorkWindow : Window
    {
        AutoShopDBEntities AutoShopModel;
        UsersEntities UserModel;
        public WorkWindow()
        {
            InitializeComponent();
            AutoShopModel = new AutoShopDBEntities();
            UserModel = new UsersEntities();
        }
        int idcustomers;
        int idproduct;
        int quantity = 1;
        string nameproduct;
        string vendor_code;
        decimal cost;
        decimal resultcost;
        Orders orders = new Orders();
        DateTime thisDate = DateTime.Now;

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            label_Copy6.Visibility = Visibility.Collapsed;
            textBox1.Visibility = Visibility.Collapsed;
        }

        private void TabItem_Loaded(object sender, RoutedEventArgs e)
        {
             AutoShopModel.ProductDetails.Load();
            dataGrid.ItemsSource = AutoShopModel.ProductDetails.Local.ToBindingList();
        }

        private void TabItem_Loaded_1(object sender, RoutedEventArgs e)
        {
            AutoShopModel.CustomerDetails.Load();
            dataGrid2.ItemsSource = AutoShopModel.CustomerDetails.Local.ToBindingList();

        }

        private void TabItem_Loaded_2(object sender, RoutedEventArgs e)
        {
             AutoShopModel.OrderDetails.Load();
            dataGrid3.ItemsSource = AutoShopModel.Orders.ToList();

        }

        private void TabItem_Loaded_3(object sender, RoutedEventArgs e)
        {
            /*var query = from orddetails in AutoShopModel.Orders
                        select new { orddetails.NameProduct, orddetails.Quantity, orddetails.Cost };
            dataGrid1.ItemsSource = query.ToList();*/
        }
        //////////// Поиск //////////////////////
        private void button_Click(object sender, RoutedEventArgs e)
        {

             if (comboBox.SelectedIndex == 0)
                {
                int tempid = Convert.ToInt32(textBox.Text);
                var query = from prod in AutoShopModel.Products
                             where prod.IDProduct == tempid
                             select prod;

               dataGrid.ItemsSource = query.ToList();
               dataGrid.Items.Refresh();
               }
            if (comboBox.SelectedIndex == 1)
            {

                string nameProd = textBox1.Text;
                string modelName = textBox.Text;

                var query = from prod in AutoShopModel.ProductDetails
                            where prod.NameProduct == nameProd && prod.NameModel == modelName
                            select prod;
                dataGrid.ItemsSource = query.ToList();
                dataGrid.Items.Refresh();
            }
            if (comboBox.SelectedIndex == 1 && textBox1.Text == "" || textBox.Text == "")
            {

                string nameProd = textBox1.Text;
                string modelName = textBox.Text;

                var query = from prod in AutoShopModel.ProductDetails
                            where prod.NameProduct == nameProd || prod.NameModel == modelName
                            select prod;
                dataGrid.ItemsSource = query.ToList();
                dataGrid.Items.Refresh();
            }
            if (comboBox.SelectedIndex == 2)
              {
                string vendorCode = textBox.Text;
                var query = from prod in AutoShopModel.ProductDetails
                            where prod.VendorCode == vendorCode
                            select prod;
                dataGrid.ItemsSource = query.ToList();
                dataGrid.Items.Refresh();
              }
            if (comboBox.SelectedIndex == 3)
            {
                string nameProd = textBox.Text;
                var query = from prod in AutoShopModel.ProductDetails
                            where prod.NameProduct == nameProd
                            select prod;
                dataGrid.ItemsSource = query.ToList();
                dataGrid.Items.Refresh();
            }
             
              }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            
            if (comboBox_Copy.SelectedIndex == 0)
            {
                int tempid = Convert.ToInt32(textBox_Copy.Text);
                var query = from prod in AutoShopModel.Customers
                            where prod.IDCustomer == tempid
                            select prod;

                dataGrid2.ItemsSource = query.ToList();
                dataGrid2.Items.Refresh();
            }

            if (comboBox_Copy.SelectedIndex == 1)
            {
                string secName = textBox_Copy.Text;
                var query = from prod in AutoShopModel.Customers
                            where prod.SecondName == secName
                            select prod;
                dataGrid2.ItemsSource = query.ToList();
                dataGrid2.Items.Refresh();
            }
        }

        private void button2copy_Click(object sender, RoutedEventArgs e)
        {
            if (comboBox_Copy1.SelectedIndex == 0)
            {
                int idorder = Convert.ToInt32(textBox_Copy1.Text);
                var query = from ord in AutoShopModel.Orders
                            where ord.IDOrder == idorder
                            select new { ord.IDOrder, ord.DateOrder, ord.StatusOrder, ord.IDCustomer, ord.Customers.FirstName, ord.Customers.SecondName, ord.IDProduct, ord.Products.NameProduct, ord.Products.VendorCode, ord.Quantity, ord.Cost, ord.Payment_State };

                dataGrid3.ItemsSource = query.ToList();
                dataGrid3.Items.Refresh();
            }
            
            if (comboBox_Copy1.SelectedIndex == 1)
            {
                int idcust = Convert.ToInt32(textBox_Copy1.Text);
                var query1 = from ord in AutoShopModel.Orders
                            where ord.IDCustomer == idcust
                             select new { ord.IDOrder, ord.DateOrder, ord.StatusOrder, ord.IDCustomer, ord.Customers.FirstName, ord.Customers.SecondName, ord.IDProduct, ord.Products.NameProduct, ord.Products.VendorCode, ord.Quantity, ord.Cost, ord.Payment_State };
                dataGrid3.ItemsSource = query1.ToList();
                dataGrid3.Items.Refresh();
            }
            if (comboBox_Copy1.SelectedIndex == 2)
            {
                string custname = textBox_Copy1.Text;
                var query1 = from ord in AutoShopModel.Orders
                             where ord.Customers.SecondName == custname
                             select new { ord.IDOrder, ord.DateOrder, ord.StatusOrder, ord.IDCustomer, ord.Customers.FirstName, ord.Customers.SecondName, ord.IDProduct, ord.Products.NameProduct, ord.Products.VendorCode, ord.Quantity, ord.Cost, ord.Payment_State };
                dataGrid3.ItemsSource = query1.ToList();
                dataGrid3.Items.Refresh();
            }
        }
        ////////////////////////////////////////////////////////////
        private void button1_Click(object sender, RoutedEventArgs e)
        {
            
            ProductDetails prod = dataGrid.SelectedItem as ProductDetails;
            idproduct = prod.IDProduct;
            nameproduct = prod.NameProduct;
            cost = prod.Price;
            vendor_code = prod.VendorCode;

            var order = new Orders
            {
                DateOrder = thisDate,
                StatusOrder = "Ожидается",
                IDCustomer = idcustomers,
                Payment_State = "Оплачен",
                ModelName = prod.NameModel,
                NameProduct = nameproduct,
                VendorCode = vendor_code,
                IDProduct = idproduct,
                Quantity = Convert.ToInt32(quantityTextBox.Text),
                Cost = Convert.ToInt32(quantityTextBox.Text) * cost
            };

            AutoShopModel.Orders.Add(order);
            AutoShopModel.SaveChanges();
            
            var queryR = from ord in AutoShopModel.Orders
                         select new { ord.IDOrder, ord.DateOrder, ord.StatusOrder, ord.IDCustomer, ord.Customers.FirstName, ord.Customers.SecondName, ord.IDProduct, ord.Products.NameProduct, ord.Quantity, ord.Cost, ord.Payment_State };

            dataGrid3.ItemsSource = queryR.ToList();
            dataGrid1.ItemsSource = AutoShopModel.OrderDetails.ToList();
            dataGrid3.Items.Refresh();
            resultcost = 0;
            foreach (var orderdetail in AutoShopModel.OrderDetails)
            {
               resultcost += orderdetail.Cost;
            }
            label2.Content = resultcost.ToString();

            tabControl.SelectedIndex = 2;

            quantity = 1;
            quantityTextBox.Text = quantity.ToString();

        }



        private void dataGrid2_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.RightShift)
            {
                tabItemCustomers.IsEnabled = false;
                unlockButton.Background = Brushes.Red;
                // Вызываем обработчик события нажатия кнопки
                CustomerDetails customers = dataGrid2.SelectedItem as CustomerDetails;
                
                idcustomers = customers.IDCustomer;
                quantityTextBox.IsEnabled = true;
                labelName.Content = customers.SecondName + " " + customers.FirstName + " " +  customers.ThirdName;
                tabControl.SelectedIndex = 1;

            }
        }

        private void unlockButton_Click(object sender, RoutedEventArgs e)
        {
            tabItemCustomers.IsEnabled = true;
            tabControl.SelectedIndex = 0;
            unlockButton.Background = Brushes.Green;
            labelName.Content = null;
        }

        private void AddUserButton_Click(object sender, RoutedEventArgs e)
        {
            NewCustomer newCustomer = new NewCustomer();
            newCustomer.Owner = this;
            newCustomer.Show();
        }

        private void button3_Click(object sender, RoutedEventArgs e)
        {
            AutoShopModel.Customers.Load();
            AutoShopModel.SaveChanges();
            dataGrid2.Items.Refresh();
        }

        private void Print_Click(object sender, RoutedEventArgs e)
        {
            
            Data.Value = labelName.Content.ToString();
            CheckWindow checkWindow = new CheckWindow();
            checkWindow.Owner = this;
            checkWindow.ShowDialog(); 
            dataGrid1.ItemsSource = null;

            resultcost = 0;
            label2.Content = resultcost.ToString();

            tabItemCustomers.IsEnabled = true;
            Data.Value = "";
            tabControl.SelectedIndex = 0;
            labelName.Content = null;
            unlockButton.Background = Brushes.Green;
          //  AutoShopModel.Database.ExecuteSqlCommand("Delete FROM [OrderDetails]");
        }

        private void IncButton_Click(object sender, RoutedEventArgs e)
        {
            quantity++;
            quantityTextBox.Text = quantity.ToString();
        }

        private void DecButton_Click(object sender, RoutedEventArgs e)
        {
            quantity--;
            quantityTextBox.Text = quantity.ToString();
        }

        private void comboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (comboBox.SelectedIndex == 1)
            {
                label.Content = "Модель";
                label_Copy6.Visibility = Visibility.Visible;
                textBox1.Visibility = Visibility.Visible;
            }
            if (comboBox.SelectedIndex != 1)
            {
                label.Content = "Поиск:";
                label_Copy6.Visibility = Visibility.Hidden;
                textBox1.Visibility = Visibility.Hidden;
            }
        }

        private void button3copy_Click(object sender, RoutedEventArgs e)
        {
            dataGrid.ItemsSource = AutoShopModel.ProductDetails.Local.ToBindingList();
        }

        //////////////////////////////////////////////////////
    }
    }

