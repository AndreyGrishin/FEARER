﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AutoShopApp
{
    /// <summary>
    /// Логика взаимодействия для NewCustomer.xaml
    /// </summary>
    public partial class NewCustomer : Window
    {
        AutoShopDBEntities AutoShopDB;
        public NewCustomer()
        {
            InitializeComponent();
            AutoShopDB = new AutoShopDBEntities();
        }

        private void Addbutton_Click_1(object sender, RoutedEventArgs e)
        {
            Customers customer = new Customers
            {
                SecondName = SecondNameTB.Text,
                FirstName = FirstNameTB.Text,
                ThirdName = ThirdNameTB.Text,
                Email = EmailTB.Text,
                Phone = PhoneTB.Text
            };
            AutoShopDB.Customers.Add(customer);
            AutoShopDB.SaveChanges();
            MessageBox.Show("Добавление нового покупателя успешно");
            this.Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            AutoShopDB.Customers.Load();
        }
        
        #region Ограничения на ввод
        private void StackPanel_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            short value;

            // Если: введена цифра
            if (Int16.TryParse(e.Text, out value))
            {
                // То: Указываем, что событие обработано и распространятся далее не должно.
                e.Handled = true;
            }
        }

        private void PhoneTB_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            short value;

            // Если: введена не цифра
            if (!Int16.TryParse(e.Text, out value))
            {
                // То: Указываем, что событие обработано и распространятся далее не должно.
                e.Handled = true;
            }
        }

        private void EmailTB_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Space)
            {
                e.Handled = true;
            }
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
        #endregion
    }
}
