
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, 2012 and Azure
-- --------------------------------------------------
-- Date Created: 04/05/2016 13:09:01
-- Generated from EDMX file: C:\Users\Юля\Documents\Visual Studio 2015\Projects\AutoShopApp\AutoShopApp\AutoShopModel.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [AutoShopDB];
GO
INSERT  Providers
VALUES
('Toyota MOTORS CORP.', 'Toypta-Cho, Toyota City, Aichi Prefecture 471-8571, Япония', 'www.toyota.com', '(093)8001212'),
('NISSAN MOTOR CO.', 'Zone d`Activites la Piece 12 CH-1180 Rolle, Switzerland', 'www.nissan.ru', '(094)4221696'),
('Mercedes', 'HPC 0518, D-70546 Stuttgart, Germany', 'www.mercedes-benz.ru,','(090)2034169'),
('MITSUBISHI MOTORS CORP.','33-8, Shiba 5-chome. Minato-ku, Tokyo 108-8410, Япония','www.mitsubishi.com,','(093)1391122'),
('PSA PEUGEOT-CITROEN','6 rue Fructidor 75835 PARIS Cedex 17 France','www.peugeot.com','(086)4004050'),
('VOLKSWAGEN AG','Berliner Ring, 2, D-38440,Wolfsburg, Germany','www.volkswagen.de','(064)7005314'),
('HYUNDAI-KIA MOTOR CO.','679-4 Seoul International Tower, Yeoksaml-dong, Gangnam-gu, Seoul, Korea','www.hyundai-motor.com','(020)5006318')
GO

INSERT Customers
(FirstName,SecondName,ThirdName,Email,Phone)
VALUES
('Гринченко', 'Григорий', 'Львович','gora@link.com','8(923)4126156'),
('Леванов', 'Александр', 'Григорьевич','lavanov.a@gmail.com','8(934)4159786'),
('Гоша', 'Лютый',NULL,NULL,'8(934)1111222'),
('Германов', 'Юрий', 'Александрович','plovecG@bk.ru','8(935)4589322'),
('Амаханова', 'Заира', NULL, 'zuhra@livan.com', '8(800)2002369'),
('Куликов', 'Денис', 'Романович','kul_den@mail.ru','8(952)8712336'),
('АвтоХим',NULL,NULL,'autogim@bk.ru','8(800)2004632'),
('Левченко', 'Андрей', 'Сергеевич','lev89@yandex.ru','8(928)4315569')
GO


INSERT INTO Products
VALUES
 ('2','Skyline R33','Подрамник','260478-964','20','20200'),
 ('1', 'Celica 03-05','Крыло переднее', '9G842-964', '7','8530'),
 ('4','Lancer 08-12','Помпа','89Ai-94O47','30','5640'),
 ('7','Rio','Стойка стабилизатора','8796446AT','15','790'),
 ('5','108','Маслянный фильтр','8633214945','41','220'),
 ('6','Phaeton','Шатун цилиндра','Е89А46-413','18','3250'),
 ('2','Teana','Бачок омывателя','EGT9729-59','26','2430'),
 ('4','Colt','Рулевая рейка','EBC899-V96','15','25320'),
 ('7','Sonata','Форсунка','ECG700-9800','21','2360')
 GO