﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HRDepartment
{
    /// <summary>
    /// Логика взаимодействия для AddNewEmployee.xaml
    /// </summary>
    public partial class AddNewEmployee : Window
    {
        EmployeeDBEntities1 DBModel;
        public AddNewEmployee()
        {
            InitializeComponent();
            DBModel = new EmployeeDBEntities1();
        }

        int idstaus;
        int idmanager;
        int iddivition;

        private void closeButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void addButton_Click(object sender, RoutedEventArgs e)
        {
            /// Добавление нового сотруднка ///
            var employee = new Employee
            {
                First_Name = FirstNameTextBox.Text,
                Sur_Name = surnamTextBox.Text,
                Third_Name = ThirdNameTextBox.Text,
                Adress = AdressTextBox.Text,
                Phone = PhoneTextBox.Text,
                IdStatus = idstaus,
                IdManager = idmanager,
                IdDivition = iddivition
            };

            DBModel.Employee.Add(employee);
            DBModel.SaveChanges();
            ///////////////////////////////////
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            /// Заполнение содержимого combobox-ов значениями из БД ///
            var query = from c in DBModel.Subdivision
                        select new { c.NameDivition, c.IdDivition };
            var query2 = from c in DBModel.StatusEmployee
                         select new { c.Status_Name, c.IdStatus };
            var query3 = from c in DBModel.Employee
                         select new { c.First_Name, c.Sur_Name, c.Third_Name};
            
            foreach (var item in query2)
            {
                comboBox.Items.Add(item.Status_Name);
            }
            foreach (var item in query)
            {
                comboBox2.Items.Add(item.NameDivition);
            }
            foreach (var item in query3)
            {
                comboBox1.Items.Add($"{item.First_Name} {item.Sur_Name} {item.Third_Name}");
            }
            ////////////////////////////////////////////////////////////
        }
        
        private void Window_Closed(object sender, EventArgs e)
        {
            /// Обновление всех элементов DataGrid после закрытия окна
            new MainWindow().RefreshDataGrid(); 
        }
        #region Ограничение на ввод
        private void PhoneTextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            short value;
            
            if (!Int16.TryParse(e.Text, out value))
            {
                e.Handled = true;
            }
           
        }

        private void StackPanel_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            short value;

            if (Int16.TryParse(e.Text, out value))
            {
                e.Handled = true;
            }
        }

        #endregion
        #region Получение id для нового сотруднкиа
        private void comboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var query = from c in DBModel.StatusEmployee
                        where c.Status_Name == comboBox.SelectedItem.ToString()
                        select new { c.IdStatus };
            foreach (var item in query)
            {
                idstaus = item.IdStatus;
            }
        }

        private void comboBox1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var query = from c in DBModel.Employee
                        where c.First_Name + " " + c.Sur_Name + " " + c.Third_Name == comboBox1.SelectedItem.ToString()
                        select new { c.IdEmployee };
            foreach (var item in query)
            {
                idmanager = (int)item.IdEmployee;
            }
        }

        private void comboBox2_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var query = from c in DBModel.Subdivision
                        where c.NameDivition == comboBox2.SelectedItem.ToString()
                        select new { c.IdDivition };
            foreach (var item in query)
            {
                iddivition = item.IdDivition;
            }
        }
        #endregion


    }

}

