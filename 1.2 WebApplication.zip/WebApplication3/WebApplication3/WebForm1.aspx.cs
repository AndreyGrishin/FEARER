﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Serialization;
using XMLSerializableProject;

namespace WebApplication3
{
    public partial class WebForm1 : System.Web.UI.Page
    {

        Settings instance1 = new Settings();
        Settings instance2;
        string filename = System.Web.Hosting.HostingEnvironment.ApplicationPhysicalPath + "\\Serialization.xml";
       
        XmlSerializer serializer = new XmlSerializer(typeof(Settings));
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
                instance1.IPAdress = TextBox2.Text;
                instance1.Mask = TextBox3.Text;
                instance1.DHCP = (bool)CheckBox1.Checked;
                instance1.WIFIAccess = (bool)CheckBox2.Checked;
                instance1.PoolAdress = TextBox4.Text;
                instance1.SSID = TextBox5.Text;
          
                using (var stream = new FileStream(filename, FileMode.Create, FileAccess.Write, FileShare.Read))
                {
                    serializer.Serialize(stream, instance1);
                }
           
        }

        protected void Button2_Click(object sender, EventArgs e)
        {

            XmlSerializer serializer = new XmlSerializer(typeof(Settings));
        
                using (var stream = new FileStream(filename, FileMode.Open, FileAccess.Read, FileShare.Read))
                {
                    instance2 = serializer.Deserialize(stream) as Settings;
                }

                TextBox2.Text = instance2.IPAdress;
                TextBox3.Text = instance2.Mask;
                CheckBox1.Checked = instance2.DHCP;
                CheckBox2.Checked = instance2.WIFIAccess;
                TextBox4.Text = instance2.PoolAdress;
                TextBox5.Text = instance2.SSID;
            }
         
        }
    }
