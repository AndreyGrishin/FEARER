﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace XMLSerializableProject
{
    [XmlRoot("Network Settings")]
    public class Settings
    {
         string mac = "fc:f5:28:61:95:58";
         string ipAdress;
         string mask;
         bool dhcp;
         string pooladress;
         bool wifiaccess;
         string ssid; 
        
        [XmlAttribute("Mac Adress")]
        [XmlIgnore]
        public string MAC
         {
            get { return mac; }
            set { mac = value;}
         }
        [XmlAttribute("IP Adress")]
        public string IPAdress
         {
            get { return ipAdress;}
            set { ipAdress = value;}
         }
        [XmlAttribute("Mask network")]
        public string Mask
        {
            get { return mask; }
            set { mask = value; }
        }
        [XmlAttribute("Сервер DHCP")]
        public bool DHCP
        {
            get { return dhcp; }
            set { dhcp = value; }
        }
        [XmlAttribute("Пулл адресов")]
        public string PoolAdress
        {
            get { return pooladress; }
            set { pooladress = value; }
        }
        [XmlAttribute("Точка доступа")]
        public bool WIFIAccess
        {
            get { return wifiaccess; }
            set { wifiaccess = value; }
        }
        [XmlAttribute("Имя сети")]
        public string SSID
        {
            get { return ssid; }
            set { ssid = value; }
        }

    }
}
